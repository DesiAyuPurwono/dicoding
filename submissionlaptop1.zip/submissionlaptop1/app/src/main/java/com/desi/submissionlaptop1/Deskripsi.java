package com.desi.submissionlaptop1;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class Deskripsi extends BaseMenu {
        TextView tvNama, tvDeskripsi, mActionBarToolbar;
        ImageView ivPhoto, ivTopbar;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_deskripsi);

            findViews();
            initListeners();
            comp();
        }

        @Override
        public void findViews() {
            ivPhoto = findViewById(R.id.iv_item_photos);
            tvNama = findViewById(R.id.tv_item_nama);
            tvDeskripsi = findViewById(R.id.tv_item_deskripsi);
            mActionBarToolbar = findViewById(R.id.tv_item_topbar);
            ivTopbar = findViewById(R.id.iv_topbar);
        }

        @Override
        public void comp() {
            mActionBarToolbar.setText("Deskripsi");

            int photo = getIntent().getIntExtra("photo", 0);
            String nama = getIntent().getStringExtra("nama");
            String deskripsi = getIntent().getStringExtra("deskripsi");
            ivPhoto.setImageResource(photo);
            tvNama.setText(nama);
            tvDeskripsi.setText(deskripsi);
        }

        @Override
        public void initListeners() {
            ivTopbar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    onBackPressed();
                }
            });
        }

        public void onBackPressed(){
            super.onBackPressed();
        }
}
