package com.desi.submissionlaptop1;

import java.util.ArrayList;

public class LaptopData {
    private static String[] laptopNames = {
            "Asus",
            "Acer",
            "Samsung",
            "Dell",
            "Toshiba",
            "Avita",
            "Lenovo",
            "Apple",
            "Xiaomi",
            "Zyrex"
    };
    private static String[] laptopDeskripsi = {
            "ASUS bersemangat tentang teknologi dan didorong oleh inovasi. Kami bermimpi, kami berani dan kami berusaha untuk menciptakan kehidupan digital yang mudah dan menyenangkan untuk semua orang. Kami selalu mencari ide dan pengalaman luar biasa, dan kami bercita-cita untuk memberikan yang luar biasa dalam segala hal yang kami lakukan.",
            "Acer Indonesia telah meraih berbagai penghargaan bergengsi dari berbagai institusi, di antaranya: Top Brand Award, Indonesia Best Brand Award dan Indonesia Customer Satisfaction Award. Acer berkomitmen untuk menjalin komunikasi tanpa batas dengan konsumen di seluruh Indonesia. Hal ini diwujudkan melalui jaringan layanan purnajual yang dapat ditemui di 66 lokasi yang tersebar di 55 kota di Indonesia, Contact Center dengan tarif lokal, Live Chat serta layanan melalui social media selama 24 jam setiap harinya. Untuk informasi mengenai produk Acer yang tersedia di pasar Indonesia beserta spesifikasi lengkapnya, Anda dapat mengunjungi www.acerid.com. Perkembangan terbaru seputar produk kami serta tips seputar dunia TI juga dapat Anda peroleh melalui akun social media Acer Indonesia",
            "Samsung manajemen kesinambungan kami bertujuan untuk menciptakan nilai berintegritas. Tidak hanya menciptakan nilai ekonomi dengan memaksimalkan keuntungan dan nilai pemegang saham, tapi kami juga lebih bertanggung jawab untuk menciptakan nilai-nilai sosial sebagai masyarakat global. Selain memberikan produk dan jasa yang inovatif serta rantai nilai berdasarkan nilai-nilai utama yang kami capai di Samsung, kami juga menciptakan nilai-nilai di bidang ekonomi, sosial dan lingkungan. Kami mengawasi dampak keuangan dan non-keuangan yang kami gunakan pada masyarakat sepanjang proses sehingga kami dapat memaksimalkan dampak positif kami serta meminimalkan berbagai hal negatif. ",
            "Dell memiliki beberapa seri laptop yang terbagi dalam dua kategori, pertama laptop untuk pasar rumahan dan perkantoran. Kedua laptop untuk bisnis. Untuk kategori yang pertama, yakni laptop untuk pasar rumahan dan perkantoran masih terbagi lagi dalam beberapa kategori laptop dan ultrabook yang meliputi: seri Inspiron untuk laptop rumahan dan perkantoran, seri XPS yang memiliki layar beresolusi tinggi dan desain menawan, seri Alienware yang menjadi idola bagi para gamers karena memiliki performa khusus gaming dengan mampu diajak bermain game berjam-jam, serta seri Vostro sebagai laptop ultraportable yang ringan dan nyaman untuk bermain dan bekerja. ",
            "Toshiba Didirikan pada tahun 1875, Toshiba Corporation adalah inovator kelas dunia dan pemimpin produk teknologi tinggi global dengan 247 anak perusahaan utama dan afiliasi di seluruh dunia. Sejak peluncuran pertama PC T1100 LAPTOP pada tahun 1985, Toshiba telah mencatat pengiriman kumulatif di seluruh dunia lebih dari 100 juta Laptop pada Tahun Buku 2010. Ke depan, pasar Laptop akan terus berkembang, dan Toshiba akan membuat produk-produk kompetitif yang menawarkan produk canggih teknologi dan kualitas.",
            "Avita, merk laptop ini mungkin masih terasa asing di telinga Anda. Tidak aneh memang mengingat merk ini baru menjejakkan kakinya di pasar Indonesia sekitar bulan November 2018 lalu. Avita sendiri merupakan produk laptop dari Nexstgo Company Ltd. yang baru didirikan tahun 2016 lalu. Meskipun terhitung sebagai pemain baru, siapa menyangka produk Avita Liber yang kami ulas kali ini menawarkan keistimewaan yang mungkin sulit ditemukan pada kompetitornya dengan harga setara.",
            "Lenovo Siapa yang menyangka jika saat ini persaingan di pasar laptop semakin ketat, sehingga membuat beberapa perusahaan laptop haruslah bersusah payah untuk menciptakan produk, yang mampu menggaet minat masyarakatnya. Untuk saat ini memang Lenovo menjadi satu dari yang terbaik untuk produk laptop, akan tetapi perlu untuk disadari disinilah anda harus tahu tentang keberadaan perushaan ini pada pringkat dunia.Sebagai salah satu perusahaan laptop asal Tiongkok, tidak membuat perusahaan ini ragu untuk melakukan segala pembaharuan, sehingga selalu membuat penggunanya puas dengan hasil yang dirasakan. Kebanyakan orang menyatakan jika laptop lenovo ini, memang sangat nyaman untuk digunakan apalagi untuk anda yang bekerja kantoran atau yang suka bermain game dan membutuhkan laptop berkualitas.Sampai saat ini Lenovo sebagai perusahaan pembuat laptop di dunia, telah mampu untuk melebarkan sayapnya dengan baik. Semua itu terbukti dari apa yang telah dicapainya pada pasar global, yang mana saat ini perusahaan Lenovo mampu bersaing dengan berbagai perusahaan di kelasnya. Siapa yang menyangka jika perusahaan ini, akhirnya mampu untuk menduduki peringkat ketiga pada pasar dunia.",
            "Macbook adalah alat terbaik untuk bisnis. Produk-produk ini membantu karyawan memecahkan masalah dengan cara kreatif, menjadi produktif di mana pun berada, dan berkolaborasi dengan lebih efektif. Perangkat keras kami yang andal serta platform yang serbaguna menciptakan lingkungan unik untuk mengembangkan aplikasi khusus untuk perusahaan Anda. Dan Anda dapat menemukan ratusan ribu apikasi untuk bisnis di App Store.",
            "Xiaomi performa tanpa kompromi dalam tubuh yang sangat ringan, sangat tipis. Mi Laptop Air memiliki layar 13,3 dan keyboard berukuran penuh dalam tubuh logam penuh. Meskipun terlihat kurus, ia sangat kuat hingga 3x kecepatan pemrosesan lebih tinggi, kecepatan RAM 15% lebih cepat, dan kinerja grafis 2,1x kali lebih tinggi pada kartu grafis khusus. Terlindungi dengan perlindungan kaca ujung-ke-ujung untuk tampilan yang dilaminasi penuh dan dilengkapi dengan Wi-Fi dual-band.",
            "Untuk sektor performa, perusahaan Zyrex menyediakan berbagai jenis laptop dengan performa yang sesuai dengan kebutuhan anda. Laptop ini hadir dengan berbagai kelas untuk sektor prosesornya mulai dari Intel Atom N570, hingga kelas wahid Intel Core i5. Untuk soal prosesor mana yang anda harus pakai kembali lagi dengan kebutuhan anda. Bagi anda yang memiliki kegiatan wajar, ringan, dan tidak terlalu berat seperti hanya aplikasi office, Zyrex Sky LM1215 cocok bagi anda. Laptop ini memiliki spesifikasi yang cukup untuk menjalankan aplikasi office biasa dan juga harga yang cukup terjangkau mulai dari 2 jutaan. Namun bagi anda yang memiliki tugas berat seperti programming, desain gambar maupun video saya sarankan memilih spesifikasi yang tinggi. Untuk hal ini Zyrex Cruiser EX4930 atau Zyrex Cruiser EX4930U memiliki spesifikasi mumpuni bisa menjadi pilihan yang bagus bagi anda."
    };
    private static int[] hostingImage = {
            R.drawable.asus,
            R.drawable.acer,
            R.drawable.samsung,
            R.drawable.dell,
            R.drawable.toshiba,
            R.drawable.avita,
            R.drawable.lenovo,
            R.drawable.apple,
            R.drawable.xiaomi,
            R.drawable.zyrex
    };
    public static ArrayList<Laptop> getListData(){
        ArrayList<Laptop> list = new ArrayList<>();

        for(int i=0;i<laptopNames.length;i++){
            Laptop host = new Laptop();
            host.setNama(laptopNames[i]);
            host.setDeskripsi(laptopDeskripsi[i]);
            host.setPhoto(hostingImage[i]);
            list.add(host);
        }
        return list;
    }
}

