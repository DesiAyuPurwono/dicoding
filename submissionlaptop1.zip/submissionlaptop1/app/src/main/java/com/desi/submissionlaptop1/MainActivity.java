package com.desi.submissionlaptop1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView rvHost;
    private ArrayList<Laptop> list = new ArrayList<>();
    ImageView ivTopbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvHost = findViewById(R.id.rv_host);
        rvHost.setHasFixedSize(true);

        ivTopbar = findViewById(R.id.iv_topbar_main);
        ivTopbar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent move = new Intent(MainActivity.this, About.class);
                startActivity(move);
            }
        });

        list.addAll(LaptopData.getListData());
        showRecyclerList();
    }

    private void showRecyclerList(){
        rvHost.setLayoutManager(new LinearLayoutManager(this));
        LaptopAdapter hostAdapter = new LaptopAdapter(list);
        rvHost.setAdapter(hostAdapter);

        hostAdapter.setOnItemClickCallback(new LaptopAdapter.OnItemClickCallback() {
            @Override
            public void onItemClicked(Laptop data) {
                intentSelectHosting(data);
            }
        });
    }

    private void intentSelectHosting(Laptop host) {
        Intent move = new Intent(MainActivity.this, Deskripsi.class);
        move.putExtra("photo", host.getPhoto());
        move.putExtra("nama", host.getNama());
        move.putExtra("deskripsi", host.getDeskripsi());
        startActivity(move);
    }
}
